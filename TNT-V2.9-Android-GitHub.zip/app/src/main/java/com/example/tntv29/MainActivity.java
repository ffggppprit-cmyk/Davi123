package com.example.tntv29;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(new PanelView(this));
    }

    private void openFreeFire() {
        String[] packages = {"com.dts.freefireth", "com.dts.freefiremax"};
        for (String packageName : packages) {
            Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(launch);
                return;
            }
        }
        new AlertDialog.Builder(this)
            .setTitle("Free Fire não encontrado")
            .setMessage("Instale o Free Fire oficial pela loja do seu dispositivo e tente novamente.")
            .setPositiveButton("OK", null)
            .show();
    }

    class PanelView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float d, w, h;
        boolean crosshair = true;
        RectF launchButton, crossButton;

        PanelView(Activity context) { super(context); d = getResources().getDisplayMetrics().density; }

        RectF rect(float l, float t, float r, float b) {
            return new RectF(l*d, t*d, r*d, b*d);
        }
        void text(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
            p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(size*d);
            p.setFakeBoldText(bold); c.drawText(s, x*d, y*d, p); p.setFakeBoldText(false);
        }
        void rounded(Canvas c, RectF r, int color, int strokeColor) {
            p.setColor(color); p.setStyle(Paint.Style.FILL);
            c.drawRoundRect(r, 12*d, 12*d, p);
            p.setColor(strokeColor); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1.4f*d);
            c.drawRoundRect(r, 12*d, 12*d, p); p.setStyle(Paint.Style.FILL);
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            w=getWidth()/d; h=getHeight()/d;
            c.drawColor(Color.rgb(8,13,24));
            rounded(c, rect(16,18,w-16,h-18), Color.rgb(17,26,43), Color.rgb(35,67,78));
            text(c,"TNT V2.9",28,55,25,Color.rgb(47,255,174),true);
            text(c,"PAINEL GAMER • MIRA VISUAL",28,78,11,Color.LTGRAY,false);

            launchButton = rect(28,98,w-28,151);
            rounded(c, launchButton, Color.rgb(18,74,60), Color.rgb(47,255,174));
            text(c,"ABRIR FREE FIRE",44,130,16,Color.WHITE,true);
            text(c,"Abre o jogo oficial instalado",44,144,9,Color.rgb(190,230,218),false);

            crossButton = rect(28,164,w-28,211);
            rounded(c, crossButton, crosshair ? Color.rgb(18,74,60) : Color.rgb(35,45,62),
                    crosshair ? Color.rgb(47,255,174) : Color.rgb(120,135,155));
            text(c,"MIRA NEON: "+(crosshair ? "LIGADA" : "DESLIGADA"),44,193,14,
                    crosshair ? Color.rgb(47,255,174) : Color.LTGRAY,true);

            text(c,"PRÉVIA DA MIRA",28,249,14,Color.WHITE,true);
            text(c,"A mira é independente e não controla o jogo.",28,269,10,Color.rgb(170,185,205),false);
            RectF arena = rect(28,286,w-28,h-92);
            p.setColor(Color.rgb(11,19,31)); p.setStyle(Paint.Style.FILL);
            c.drawRoundRect(arena, 14*d, 14*d, p);
            if (crosshair) {
                float cx=w/2*d, cy=(h/2+10)*d;
                p.setColor(Color.rgb(47,255,174)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2*d);
                c.drawCircle(cx,cy,13*d,p);
                c.drawLine(cx-28*d,cy,cx-8*d,cy,p);
                c.drawLine(cx+8*d,cy,cx+28*d,cy,p);
                c.drawLine(cx,cy-28*d,cx,cy-8*d,p);
                c.drawLine(cx,cy+8*d,cx,cy+28*d,p);
                p.setStyle(Paint.Style.FILL); c.drawCircle(cx,cy,2.5f*d,p);
                p.setStyle(Paint.Style.FILL);
            } else {
                text(c,"Mira desligada",w/2-39,h/2+14,12,Color.GRAY,false);
            }
            text(c,"DEMONSTRAÇÃO VISUAL • SEM AIMBOT",28,h-53,10,Color.rgb(47,255,174),true);
            text(c,"Não detecta nem acompanha inimigos reais.",28,h-34,10,Color.rgb(170,185,205),false);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_UP) {
                float x=e.getX(), y=e.getY();
                if (launchButton != null && launchButton.contains(x,y)) {
                    openFreeFire();
                } else if (crossButton != null && crossButton.contains(x,y)) {
                    crosshair = !crosshair;
                    invalidate();
                }
                return true;
            }
            return true;
        }
    }
}
